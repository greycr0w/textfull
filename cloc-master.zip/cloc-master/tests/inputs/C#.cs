// from http://www.roesler-ac.de/wolfram/hello.htm
// Hello World in Microsoft C# ("C-Sharp").

using System;

class HelloWorld
{
    public static int Main(String[] args)
    {
        Console.WriteLine("Hello, World!");
        return 0;
    }
}
