-- single line comment

--[[
multi 
line 
comment
]]

--[[
also a comment
--]]

print("hello, world")
print([[not a comment]])
