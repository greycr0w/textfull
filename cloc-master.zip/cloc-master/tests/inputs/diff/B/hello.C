// hello.C -- stuff
#include <iostream>
int main ()
{
    std::cout << "hello" << std::endl;  // comment 1
    std::cout << "again" << std::endl;  /* comment
                                           2 */
}
