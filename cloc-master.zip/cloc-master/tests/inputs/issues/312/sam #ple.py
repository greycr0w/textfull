#!/usr/bin/env python
print('https://github.com/AlDanial/cloc/issues/312')
