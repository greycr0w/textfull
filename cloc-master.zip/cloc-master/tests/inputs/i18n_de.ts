<!-- http://code.qt.io/cgit/qt/qtbase.git/tree/examples/widgets/tools/i18n/translations/i18n_de.ts -->
<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>View</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message> <!-- some comments -->
    <message>
        <source>E&amp;xit</source>
        <translation>Be&amp;enden</translation>
    </message>
<!-- 
     some comments
     -->
    <message>
        <source>First</source>
        <translation>Erstens</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>Drittens</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Deutsch</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>Sprache: %1</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Schief</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>Zweitens</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>Isometrisch</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>Perspektivisch</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>Internationalisierungsbeispiel</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
